import { initializeApp } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-app.js";
import { getAuth, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, GoogleAuthProvider, signInWithPopup } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-auth.js";
import { getFirestore, collection, addDoc, getDocs, query, orderBy, where, serverTimestamp, deleteDoc, doc } from "https://www.gstatic.com/firebasejs/10.9.0/firebase-firestore.js";

const firebaseConfig = {
  projectId: "dket-hack",
  appId: "1:744062770785:web:d48ec35b4ac56192301420",
  storageBucket: "dket-hack.firebasestorage.app",
  apiKey: "AIzaSyAapN9Un3g7T9xzIw7vS1q55Tmqhryt5Tc",
  authDomain: "dket-hack.firebaseapp.com",
  messagingSenderId: "744062770785",
  measurementId: "G-27L959S8W9"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const googleProvider = new GoogleAuthProvider();
const db = getFirestore(app);

export { auth, db, signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut, onAuthStateChanged, googleProvider, signInWithPopup, collection, addDoc, getDocs, query, orderBy, where, serverTimestamp, deleteDoc, doc };
